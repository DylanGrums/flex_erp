export { promotionsLoader } from "./loader.ts"
export { PromotionsList as Component } from "./promotions-list.tsx"
