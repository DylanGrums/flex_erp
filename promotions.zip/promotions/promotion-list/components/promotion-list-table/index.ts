export * from "./promotion-list-table"
