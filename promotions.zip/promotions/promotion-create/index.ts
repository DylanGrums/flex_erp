export { PromotionCreate as Component } from "./promotion-create"
