export { PromotionEditDetails as Component } from "./promotion-edit-details"
