export { PromotionAddCampaign as Component } from "./promotion-add-campaign"
