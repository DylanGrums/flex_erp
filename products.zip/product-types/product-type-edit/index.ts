export { ProductTypeEdit as Component } from "./product-type-edit"
