export { ProductTypeMetadata as Component } from "./product-type-metadata"
