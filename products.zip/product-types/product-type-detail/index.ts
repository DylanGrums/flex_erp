export { ProductTypeDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { productTypeLoader as loader } from "./loader"
export { ProductTypeDetail as Component } from "./product-type-detail"
