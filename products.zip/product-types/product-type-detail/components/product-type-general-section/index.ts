export * from "./product-type-general-section"
