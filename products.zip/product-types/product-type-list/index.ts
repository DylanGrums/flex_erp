export { ProductTypeList as Component } from "./product-type-list"
