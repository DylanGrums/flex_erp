export { ProductTypeCreate as Component } from "./product-type-create"
