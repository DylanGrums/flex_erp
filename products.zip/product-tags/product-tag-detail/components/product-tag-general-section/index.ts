export * from "./product-tag-general-section"
