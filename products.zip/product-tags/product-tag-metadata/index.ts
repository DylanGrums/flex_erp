export { ProductTagMetadata as Component } from "./product-tag-metadata"
