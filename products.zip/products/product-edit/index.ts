export { ProductEdit as Component } from "./product-edit"
