export * from "./product-general-section";
