export { ProductDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { productLoader as loader } from "./loader"
export { ProductDetail as Component } from "./product-detail"
