export { ProductCreate as Component } from "./product-create"
