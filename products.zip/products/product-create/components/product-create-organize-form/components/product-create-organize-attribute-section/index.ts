export * from "./product-create-details-attribute-section"
