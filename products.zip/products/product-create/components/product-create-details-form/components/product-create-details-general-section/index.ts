export * from "./product-create-general-section"
