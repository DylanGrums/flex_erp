export * from "./product-create-details-media-section"
