export { ProductEditOption as Component } from "./product-edit-option"
