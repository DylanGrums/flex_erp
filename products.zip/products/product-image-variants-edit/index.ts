export { ProductImageVariantsEdit as Component } from "./product-image-variants-edit"
