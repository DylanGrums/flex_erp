export { ProductExport as Component } from "./product-export"
