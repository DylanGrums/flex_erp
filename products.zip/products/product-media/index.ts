export { ProductMedia as Component } from "./product-media"
