export const PRODUCT_VARIANT_IDS_KEY = "product_variant_ids"
