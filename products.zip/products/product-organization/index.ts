export { ProductOrganization as Component } from "./product-organization"
