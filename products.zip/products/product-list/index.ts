export { productsLoader as productLoader } from "./loader"
export { ProductList as Component } from "./product-list"
