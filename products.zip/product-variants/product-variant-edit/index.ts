export { ProductVariantEdit as Component } from "./product-variant-edit"
export { editProductVariantLoader as loader } from "./loader"
