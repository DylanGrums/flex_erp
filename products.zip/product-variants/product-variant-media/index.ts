export { ProductVariantMedia as Component } from "./product-variant-media"
