export * from "./variant-general-section"
