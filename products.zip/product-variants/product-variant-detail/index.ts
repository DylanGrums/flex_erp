export { ProductVariantDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { variantLoader as loader } from "./loader"
export { ProductVariantDetail as Component } from "./product-variant-detail"
