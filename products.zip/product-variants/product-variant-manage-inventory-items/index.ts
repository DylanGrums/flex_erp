export { ProductVariantManageInventoryItems as Component } from "./product-variant-manage-inventory-items"
