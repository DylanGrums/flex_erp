export { ProductVariantMetadata as Component } from "./product-variant-metadata"
